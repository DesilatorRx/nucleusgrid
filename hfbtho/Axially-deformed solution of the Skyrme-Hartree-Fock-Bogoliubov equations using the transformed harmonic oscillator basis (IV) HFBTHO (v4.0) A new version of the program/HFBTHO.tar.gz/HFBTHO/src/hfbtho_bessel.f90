!***********************************************************************
!
!    Copyright (c) 2021, Lawrence Livermore National Security, LLC.
!                        Produced at the Lawrence Livermore National
!                        Laboratory.
!                        Lead developer: Nicolas Schunck, schunck1@llnl.gov
!    HFBTHO
!    -----
!      LLNL-CODE-826901 All rights reserved.
!      LLNL-CODE-728299 All rights reserved.
!      LLNL-CODE-573953 All rights reserved.
!
!      Copyright 2021, P. Marevic, N. Schunck, E. Ney, R. Navarro Perez,
!                      M. Verriere, J. O'Neal
!      Copyright 2017, R. Navarro Perez, N. Schunck, R. Lasseri, C. Zhang,
!                      J. Sarich
!      Copyright 2012, M.V. Stoitsov, N. Schunck, M. Kortelainen, H.A. Nam,
!                      N. Michel, J. Sarich, S. Wild
!      Copyright 2005, M.V. Stoitsov, J. Dobaczewski, W. Nazarewicz, P.Ring
!
!
!    This file is part of HFBTHO.
!
!    HFBTHO is free software: you can redistribute it and/or modify it
!    under the terms of the GNU General Public License as published by
!    the Free Software Foundation, either version 3 of the License, or
!    (at your option) any later version.
!
!    HFBTHO is distributed in the hope that it will be useful, but
!    WITHOUT ANY WARRANTY; without even the implied warranty of
!    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
!    GNU General Public License for more details.
!
!    You should have received a copy of the GNU General Public License
!    along with HFBTHO. If not, see <http://www.gnu.org/licenses/>.
!
!    OUR NOTICE AND TERMS AND CONDITIONS OF THE GNU GENERAL PUBLIC
!    LICENSE
!
!    Our Preamble Notice
!
!      A. This notice is required to be provided under our contract
!         with the U.S. Department of Energy (DOE). This work was
!         produced at the Lawrence Livermore National Laboratory under
!         Contract No. DE-AC52-07NA27344 with the DOE.
!      B. Neither the United States Government nor Lawrence Livermore
!         National Security, LLC nor any of their employees, makes any
!         warranty, express or implied, or assumes any liability or
!         responsibility for the accuracy, completeness, or usefulness
!         of any information, apparatus, product, or process disclosed,
!         or represents that its use would not infringe privately-owned
!         rights.
!      C. Also, reference herein to any specific commercial products,
!         process, or services by trade name, trademark, manufacturer
!         or otherwise does not necessarily constitute or imply its
!         endorsement, recommendation, or favoring by the United States
!         Government or Lawrence Livermore National Security, LLC. The
!         views and opinions of authors expressed herein do not
!         necessarily state or reflect those of the United States
!         Government or Lawrence Livermore National Security, LLC, and
!         shall not be used for advertising or product endorsement
!         purposes.
!
!    The precise terms and conditions for copying, distribution and
!    modification are contained in the file COPYING.
!
!***********************************************************************

! ==================================================================== !
!                                                                      !
!                      BESSEL FUNCTIONS PACKAGE                        !
!                                                                      !
! ==================================================================== !

!-------------------------------------------------------------------
!>  This module provides a set of routines to compute the modified Bessel
!>  functions of the first kind, with or without exponential scaling.
!>
!>  @author
!>  Nicolas Schunck
!-------------------------------------------------------------------
!  Subroutines: - calci0 ( arg, result, jint )
!               - calci1(arg,result,jint)
!  Functions: - besei0(x)
!             - besei1(x)
!----------------------------------------------------------------------!

Module bessik

  Use HFBTHO_utilities

  Implicit None

  Public besei0,besei1

  Private calci0,calci1

Contains
  !=======================================================================
  !>  BESEI0 evaluates the exponentially scaled Bessel \f$ I_0(X) \f$ function.
  !>
  !>  Discussion:
  !>    This routine computes approximate values for the modified Bessel
  !>    function of the first kind of order zero multiplied by
  !>   \f$ \exp(-|x|) \f$.
  !>
  !>  Licensing:
  !>    This code is distributed under the GNU LGPL license.
  !>
  !>  Modified:
  !>    03 April 2007
  !>
  !>  Author:
  !>    Original FORTRAN77 version by William Cody.
  !>    FORTRAN90 version by John Burkardt.
  !>
  !>  Parameters:
  !>    Input, real ( kind = 8 ) X, the argument of the function.
  !>    Output, real ( kind = 8 ) BESEI0, the value of the function.
  !=======================================================================
  Real(pr) Function besei0(x)
    Real(pr), Intent(In) :: x

    Integer(ipr) :: jint
    Real(pr) :: result

    jint = 2
    Call calci0(x,result,jint)
    besei0 = result

  End Function besei0
  !=======================================================================
  !> BESEI1 evaluates the exponentially scaled Bessel \f$ I_1(x) \f$
  !> function.
  !>
  !>  Discussion:
  !>    This routine computes approximate values for the modified Bessel
  !>    function of the first kind of order one multiplied by
  !>    \f$ \exp(-|x|) \f$.
  !>
  !>  Licensing:
  !>    This code is distributed under the GNU LGPL license.
  !>
  !>  Modified:
  !>    03 April 2007
  !>
  !>  Author:
  !>    Original FORTRAN77 version by William Cody.
  !>    FORTRAN90 version by John Burkardt.
  !>
  !>  Parameters:
  !>    Input, real ( kind = 8 ) X, the argument of the function.
  !>    Output, real ( kind = 8 ) BESEI1, the value of the function.
  !=======================================================================
  Real(pr) Function besei1(x)
    Real(pr), Intent(In) :: x

    Integer(ipr) :: jint
    Real(pr) :: result

    jint = 2
    Call calci1(x,result,jint)
    besei1 = result

  End Function besei1
  !=======================================================================
  !> CALCI0 computes various I0 Bessel functions.
  !>
  !>  Discussion:
  !>    This routine computes modified Bessel functions of the first kind
  !>    and order zero, \f$ I_0(x) \f$ and \f$ \exp(-|x|)I_0(X) \f$, for
  !>    real arguments x. The main computation evaluates slightly modified
  !>    forms of minimax approximations generated by Blair and Edwards,
  !>    Chalk River (Atomic Energy of Canada Limited) Report AECL-4928,
  !>    October, 1974.
  !>
  !>  Licensing:
  !>    This code is distributed under the GNU LGPL license.
  !>
  !>  Modified:
  !>    03 April 2007
  !>
  !>  Author:
  !>    Original FORTRAN77 version by William Cody, Laura Stoltz.
  !>    FORTRAN90 version by John Burkardt.
  !>
  !>  Parameters:
  !>    - Input, real ( kind = 8 ) ARG, the argument.  If JINT = 1, then
  !>      the argument must be less than XMAX.
  !>    - Input, integer ( kind = 4 ) JINT, chooses the function to be computed.
  !>       1. \f$ I_0(x)\f$
  !>       2. \f$ \exp(-x) I_0(x) \f$
  !>    - Output, real ( kind = 8 ) RESULT, the value of the function,
  !>      which depends on the input value of JINT:
  !>       1. RESULT = \f$ I_0(x)\f$
  !>       2. RESULT = \f$ \exp(-x) I_0(x) \f$
  !=======================================================================
  Subroutine calci0(arg, result, jint)
    Real(pr), Intent(In) :: arg
    Integer(ipr), Intent(In) :: jint
    Real(pr), Intent(Out) :: result

    Integer(ipr) :: i
    Real(pr) :: a,b,sump,sumq,x,xx
    !  Mathematical constants
    Real(pr), Parameter :: one5  = 15.0_pr
    Real(pr), Parameter :: exp40 = 2.353852668370199854e17_pr
    Real(pr), Parameter :: forty = 40.0_pr
    Real(pr), Parameter :: rec15 = 6.6666666666666666666e-2_pr
    Real(pr), Parameter :: two25 = 225.0_pr
    !  Machine-dependent constants
    Real(pr), Parameter :: xsmall = 5.55e-17_pr
    Real(pr), Parameter :: xinf = 1.79e308_pr
    Real(pr), Parameter :: xmax = 713.986_pr
    !  Coefficients for XSMALL <= ABS(ARG) < 15.0
    Real(pr), Dimension(1:15), Parameter :: p = [ -5.2487866627945699800e-18_pr,-1.5982226675653184646e-14_pr, &
                                                  -2.6843448573468483278e-11_pr,-3.0517226450451067446e-08_pr, &
                                                  -2.5172644670688975051e-05_pr,-1.5453977791786851041e-02_pr, &
                                                  -7.0935347449210549190e+00_pr,-2.4125195876041896775e+03_pr, &
                                                  -5.9545626019847898221e+05_pr,-1.0313066708737980747e+08_pr, &
                                                  -1.1912746104985237192e+10_pr,-8.4925101247114157499e+11_pr, &
                                                  -3.2940087627407749166e+13_pr,-5.5050369673018427753e+14_pr, &
                                                  -2.2335582639474375249e+15_pr ]
    Real(pr), Dimension(1:5), Parameter :: q = [ -3.7277560179962773046e+03_pr, 6.5158506418655165707e+06_pr, &
                                                 -6.5626560740833869295e+09_pr, 3.7604188704092954661e+12_pr, &
                                                 -9.7087946179594019126e+14_pr ]
    !  Coefficients for 15.0 <= ABS(ARG)
    Real(pr), Dimension(1:8), Parameter :: pp = [ -3.9843750000000000000e-01_pr, 2.9205384596336793945e+00_pr, &
                                                  -2.4708469169133954315e+00_pr, 4.7914889422856814203e-01_pr, &
                                                  -3.7384991926068969150e-03_pr,-2.6801520353328635310e-03_pr, &
                                                   9.9168777670983678974e-05_pr,-2.1877128189032726730e-06_pr ]
    Real(pr), Dimension(1:7), Parameter :: qq = [ -3.1446690275135491500e+01_pr, 8.5539563258012929600e+01_pr, &
                                                  -6.0228002066743340583e+01_pr, 1.3982595353892851542e+01_pr, &
                                                  -1.1151759188741312645e+00_pr, 3.2547697594819615062e-02_pr, &
                                                  -5.5194330231005480228e-04_pr ]

    x = Abs(arg)

    If(x <xsmall) Then

       result = one
    !
    !  XSMALL <= ABS(ARG) < 15.0.
    !
    Else If (x<one5) Then

       xx = x * x
       sump = p(1)
       Do i = 2, 15
          sump = sump * xx + p(i)
       End Do
       xx = xx - two25

       sumq = (((( xx + q(1) ) * xx + q(2) ) * xx + q(3) ) * xx + q(4) ) * xx + q(5)

       result = sump / sumq

       If(jint == 2) Then
          result = result * Exp(-x)
       End If

    Else If (one5<=x) Then

       If(jint==1 .and. xmax<x) Then
          result = xinf
       Else
          !
          !  15.0 <= ABS(ARG).
          !
          xx = one / x - rec15

          sump = (((((( pp(1) * xx + pp(2) ) * xx + pp(3) ) * xx + pp(4) ) &
               * xx + pp(5) ) * xx + pp(6) ) * xx + pp(7) ) * xx + pp(8)

          sumq = (((((( xx + qq(1) ) * xx + qq(2) ) * xx + qq(3) ) * xx + qq(4) ) &
                      * xx + qq(5) ) * xx + qq(6) ) * xx + qq(7)

          result = sump / sumq

          If(jint == 2) Then
             result = (result - pp(1)) / Sqrt(x)
          Else
             !
             !  Calculation reformulated to avoid premature overflow.
             !
             If(x <= (xmax-one5)) Then
                a = Exp(x)
                b = one
             Else
                a = Exp(x-forty)
                b = exp40
             End If

             result = ( (result*a - pp(1)*a) / Sqrt(x) ) * b

          End If

       End If

    End If

  End Subroutine calci0
  !=======================================================================
  !>  CALCI1 computes various I1 Bessel functions.
  !>
  !>  Discussion:
  !>    This routine computes modified Bessel functioons of the first kind
  !>    and order one, \f$ I_1(x) \f$ and \f$ \exp(-|x|) I_1(x) \f$, for real
  !>    arguments x. The main computation evaluates slightly modified forms
  !>    of minimax approximations generated by Blair and Edwards, Chalk
  !>    River (Atomic Energy of Canada Limited) Report AECL-4928,
  !>    October, 1974.
  !>
  !>  Licensing:
  !>    This code is distributed under the GNU LGPL license.
  !>
  !>  Modified:
  !>    03 April 2007
  !>
  !>  Author:
  !>    Original FORTRAN77 version by William Cody, Laura Stoltz.
  !>    FORTRAN90 version by John Burkardt.
  !>
  !>  Parameters:
  !>    - Input, real ( kind = 8 ) ARG, the argument.  If JINT = 1, then
  !>      the argument must be less than XMAX.
  !>    - Input, integer ( kind = 4 ) JINT, chooses the function to be computed.
  !>       1. \f$ I_1(x)\f$
  !>       2. \f$ \exp(-x) I_1(x) \f$
  !>    - Output, real ( kind = 8 ) RESULT, the value of the function,
  !>      which depends on the input value of JINT:
  !>       1. RESULT = \f$ I_1(x)\f$
  !>       2. RESULT = \f$ \exp(-x) I_1(x) \f$
  !=======================================================================
  Subroutine calci1(arg,result,jint)
    Real(pr), Intent(In) :: arg
    Integer(ipr), Intent(In) :: jint
    Real(pr), Intent(Out) :: result

    Integer(ipr) :: j
    Real(pr) :: a,b,sump,sumq,x,xx
    !  Mathematical constants
    Real(pr), Parameter :: one5  = 15.0_pr
    Real(pr), Parameter :: exp40 = 2.353852668370199854e17_pr
    Real(pr), Parameter :: forty = 40.0_pr
    Real(pr), Parameter :: rec15 = 6.6666666666666666666e-2_pr
    Real(pr), Parameter :: two25 = 225.0_pr
    !  Machine-dependent constants
    Real(pr), Parameter :: xsmall = 5.55e-17_pr
    Real(pr), Parameter :: xinf = 1.79e308_pr
    Real(pr), Parameter :: xmax = 713.986_pr
    !  Coefficients for XSMALL <= ABS(ARG) < 15.0
    Real(pr), Dimension(1:15), Parameter :: p = [1.9705291802535139930e-19_pr,-6.5245515583151902910e-16_pr, &
                                                 1.1928788903603238754e-12_pr,-1.4831904935994647675e-09_pr, &
                                                 1.3466829827635152875e-06_pr,-9.1746443287817501309e-04_pr, &
                                                 4.7207090827310162436e-01_pr,-1.8225946631657315931e+02_pr, &
                                                 5.1894091982308017540e+04_pr,-1.0588550724769347106e+07_pr, &
                                                 1.4828267606612366099e+09_pr,-1.3357437682275493024e+11_pr, &
                                                 6.9876779648010090070e+12_pr,-1.7732037840791591320e+14_pr, &
                                                 1.4577180278143463643e+15_pr ]
    Real(pr), Dimension(1:5), Parameter :: q = [ 4.0076864679904189921e+03_pr, 7.4810580356655069138e+06_pr, &
                                                 8.0059518998619764991e+09_pr, 4.8544714258273622913e+12_pr, &
                                                 1.3218168307321442305e+15_pr ]
    !  Coefficients for 15.0 <= ABS(ARG)
    Real(pr), Dimension(1:8), Parameter :: pp = [-6.0437159056137600000e-02_pr, 4.5748122901933459000e-01_pr, &
                                                 -4.2843766903304806403e-01_pr, 9.7356000150886612134e-02_pr, &
                                                 -3.2457723974465568321e-03_pr,-3.6395264712121795296e-04_pr, &
                                                  1.6258661867440836395e-05_pr,-3.6347578404608223492e-07_pr ]
    Real(pr), Dimension(1:6), Parameter :: qq = [-3.8806586721556593450e+00_pr, 3.2593714889036996297e+00_pr, &
                                                 -8.5017476463217924408e-01_pr, 7.4212010813186530069e-02_pr, &
                                                 -2.2835624489492512649e-03_pr, 3.7510433111922824643e-05_pr ]
    Real(pr), Parameter :: pbar = 3.98437500e-01_pr

    x = Abs(arg)
    !
    !  Return for ABS(ARG) < XSMALL.
    !
    If(x<xsmall) Then

       result = half * x
    !
    !  XSMALL <= ABS(ARG) < 15.0.
    !
    Else If (x<one5) Then

       xx = x * x
       sump = p(1)
       Do j = 2, 15
          sump = sump * xx + p(j)
       End Do
       xx = xx - two25

       sumq = (((( xx + q(1) ) * xx + q(2) ) * xx + q(3) ) * xx + q(4) ) * xx + q(5)

       result = ( sump / sumq ) * x

       If(jint==2) Then
          result = result *Exp(-x)
       End If

    Else If (jint==1 .and. xmax<x) Then

       result = xinf

    Else
       !
       !  15.0 <= ABS(ARG).
       !
       xx = one / x - rec15

       sump = (((((( pp(1) * xx + pp(2) ) * xx + pp(3) ) * xx + pp(4) ) * xx + pp(5) ) &
                           * xx + pp(6) ) * xx + pp(7) ) * xx + pp(8)

       sumq = ((((( xx + qq(1) ) * xx + qq(2) ) * xx + qq(3) ) &
                  * xx + qq(4) ) * xx + qq(5) ) * xx + qq(6)

       result = sump / sumq

       If(jint/=1) Then
          result = (result + pbar) / Sqrt(x)
       Else
          !
          !  Calculation reformulated to avoid premature overflow.
          !
          If((xmax-one5)<x) Then
             a = Exp(x-forty)
             b = exp40
          Else
             a = Exp(x)
             b = one
          End If

          result = ( (result*a + pbar*a) / Sqrt(x) ) * b

       End If
    End If

    If(arg<zero) Then
       result = -result
    End If

  End Subroutine calci1
  !=======================================================================
  !
  !=======================================================================
End Module bessik
